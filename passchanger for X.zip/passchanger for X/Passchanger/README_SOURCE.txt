﻿╔════════════════════════════════════════════════════════════════════╗
║            MS ACCOUNT PASSWORD CHANGER v2.0                        ║                  By Gamerzmub
║                   SOURCE CODE EDITION                              ║
╚════════════════════════════════════════════════════════════════════╝

📦 PROJECT STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MS-Password-Changer/
│
├── 📄 main.py                    # Main application entry point
├── 📄 run.py                     # Smart launcher with pre-flight checks
├── 📄 tempmail.py                # Temporary email service (mail.tm API)
├── 📄 config.json                # Configuration (webhook, server URL)
├── 📄 requirements.txt           # Python dependencies
├── 📄 advanced_exe_builder.py   # Build script for EXE
├── 📄 README_SOURCE.txt          # This file
│
├── 📁 gui/                       # User interface
│   ├── __init__.py
│   ├── auth_screen.py           # Discord authentication UI
│   ├── main_window.py           # Main interface (account management)
│   ├── processing_screen.py    # Processing UI with logs & CAPTCHA
│   └── styles.py                # UI styling and themes
│
├── 📁 automation/                # Automation core
│   ├── __init__.py
│   ├── core.py                  # Account info scraper
│   ├── acsr.py                  # ACSR form submission
│   ├── acsr_continue.py         # ACSR flow continuation
│   ├── driver.py                # WebDriver factory
│   ├── reset_password.py        # Password reset automation
│   ├── captcha.py               # CAPTCHA handler
│   └── logger.py                # Discord webhook logger
│
└── 📁 utils/                     # Utility modules
    ├── __init__.py
    ├── api_client.py            # Flask API communication
    ├── password_generator.py   # ShulkerGen password generator
    └── session_manager.py       # User session persistence

🚀 INSTALLATION & SETUP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PREREQUISITES:
--------------
✓ Python 3.8 or higher
✓ pip (Python package manager)
✓ Google Chrome browser (latest)
✓ Git (optional, for cloning)

STEP 1: Install Python Dependencies
------------------------------------
Open terminal/command prompt in project folder:

    pip install -r requirements.txt

This installs:
• discord.py - Discord bot integration
• Flask - Web server for authentication
• requests - HTTP client
• customtkinter - Modern GUI framework
• Pillow - Image processing
• selenium - Browser automation
• undetected-chromedriver - Anti-detection driver
• aiohttp - Async HTTP

STEP 2: Configure config.json
------------------------------
Edit config.json with your settings:

{
    "webhook_url": "YOUR_DISCORD_WEBHOOK_URL",
    "flask_server": "http://YOUR_SERVER:PORT",
    "steve_user_id": "YOUR_DISCORD_USER_ID"
}

• webhook_url: Where successful results are sent
• flask_server: Authentication server endpoint
• steve_user_id: Admin Discord ID

STEP 3: Run the Application
----------------------------
    python run.py

Or directly:
    python main.py

🏗️ ARCHITECTURE OVERVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

APPLICATION FLOW:
-----------------
1. run.py (Launcher)
   ↓ Pre-flight checks (Chrome, certificates)
   ↓ Dynamic import of main.py
   
2. main.py (Entry Point)
   ↓ Initialize CustomTkinter app
   ↓ Check saved session
   
3. auth_screen.py (Authentication)
   ↓ Discord ID input
   ↓ API authorization check
   ↓ OTP verification
   ↓ Save session
   
4. main_window.py (Main Interface)
   ↓ Account management (add/upload/remove)
   ↓ Auto password toggle
   ↓ Start processing button
   
5. processing_screen.py (Processing)
   ↓ For each account:
       ├── core.py: Scrape account info
       ├── acsr.py: Submit ACSR form
       ├── captcha.py: Download CAPTCHA
       ├── User solves CAPTCHA
       ├── acsr_continue.py: Complete ACSR
       ├── reset_password.py: Reset password
       └── logger.py: Send to webhook

📋 MODULE DESCRIPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ENTRY POINTS:
-------------
run.py:
  • Smart launcher with environment checks
  • Verifies Chrome installation
  • Fixes seleniumwire certificate issues
  • Handles PyInstaller frozen state
  • Dynamic module import for obfuscation compatibility

main.py:
  • Main application class (MSPasswordChangerApp)
  • Window configuration and centering
  • Session restoration on startup
  • Screen navigation management

GUI MODULES (gui/):
-------------------
auth_screen.py:
  • Discord User ID input form
  • Authorization check via API client
  • OTP request and verification
  • Session saving after authentication
  • Not authorized error screen
  • 3 OTP attempt limit with lockout

main_window.py:
  • Account list management (add/remove/clear)
  • Single account dialog with validation
  • Bulk upload from txt file
  • Auto password checkbox toggle
  • Scrollable account display
  • Logout with session clearing
  • Processing initiation

processing_screen.py:
  • Real-time log display (CTkTextbox)
  • CAPTCHA image display with PIL
  • CAPTCHA input and submission
  • Progress tracking (current/total)
  • Success/failure counters
  • Threaded account processing
  • Password prompt dialog (if auto-off)
  • CAPTCHA retry handling (max 3)
  • Webhook notification on completion
  • Back to main button

styles.py:
  • Color scheme (purple/blue/teal gradient)
  • Font definitions (title, heading, body)
  • Button styles (primary, success, danger)
  • Entry field styles
  • Frame styles with borders
  • Window dimensions

AUTOMATION MODULES (automation/):
----------------------------------
core.py:
  • scrape_account_info(email, password)
  • Logs into Microsoft account
  • Handles multiple login flows:
    - Direct password input
    - "Use your password" button
    - "Other ways to sign in" button
    - Legacy credential picker
  • Detects incorrect password
  • Handles rate limiting (retries)
  • Closes security prompts
  • Scrapes Microsoft profile:
    - Full name
    - Date of birth
    - Country/Region
  • Scrapes Skype profile:
    - Skype ID
    - Skype email
  • Scrapes Xbox profile:
    - Gamertag extraction from URL
  • Returns dict with all account info

acsr.py:
  • submit_acsr_form(account_info)
  • Generates temporary email via tempmail.py
  • Configures proxy (optional, currently disabled)
  • Opens Microsoft ACSR page
  • Fills account email
  • Fills recovery email (tempmail)
  • Downloads CAPTCHA image
  • Returns: captcha_image, driver, token, tempmail

acsr_continue.py:
  • continue_acsr_flow(driver, account_info, token, captcha_text, user_id)
  • Submits CAPTCHA solution
  • Handles CAPTCHA retry on failure
  • Waits for OTP via tempmail
  • Submits OTP code
  • Fills personal information:
    - First and last name parsing
    - DOB dropdown selection (month/day/year)
    - Country/Region
  • Enters old password
  • Selects product options (Skype, Xbox)
  • Fills Skype information
  • Selects Xbox One platform
  • Enters Xbox Gamertag
  • Waits for reset email (2nd email)
  • Extracts password reset link
  • Returns reset link or error code

driver.py:
  • create_driver(headless, use_proxy, proxy_config)
  • Creates Chrome WebDriver with selenium-wire
  • Configures headless/headed mode
  • Sets up proxy authentication (if enabled)
  • Anti-detection measures:
    - Disables automation flags
    - Custom user agent (Linux/Windows)
    - WebDriver property masking
    - Plugin spoofing
  • Finds Chrome binary in common locations
  • Handles WebDriver Manager installation
  • Returns configured driver instance

reset_password.py:
  • perform_password_reset(resetlink, email, new_password)
  • Opens password reset link
  • Enters account email
  • Fills new password (twice)
  • Submits form
  • Handles password rejection:
    - Automatically retries with fallback
    - Fallback: "ShulkerCorePass!12"
  • Returns actual password used
  • Takes screenshot on failure

captcha.py:
  • download_captcha(driver)
  • Finds CAPTCHA image element (GetHIPData)
  • Downloads image from source URL
  • Converts to PNG via PIL
  • Returns BytesIO buffer

logger.py:
  • send_webhook(results, webhook_url)
  • Formats successful account results
  • Sends to Discord webhook
  • Includes all account details:
    - Email, old/new passwords
    - Name, DOB, region
    - Skype ID/email
    - Xbox Gamertag

UTILITY MODULES (utils/):
--------------------------
api_client.py:
  • APIClient class for Flask server communication
  • check_authorization(user_id):
    - POST /check_auth
    - Returns (authorized: bool, message: str)
  • request_otp(user_id):
    - POST /request_otp
    - Triggers Discord DM with OTP
    - Returns (success: bool, message: str)
  • verify_otp(user_id, otp):
    - POST /verify_otp
    - Validates 6-digit code
    - Returns (success: bool, message: str)
  • health_check():
    - GET /health
    - Server connectivity test
  • 5 second timeout on all requests
  • Handles ConnectionError, Timeout exceptions

password_generator.py:
  • generate_shulker_password():
    - Format: ShulkerGen######
    - Returns string with 6 random digits
    - Example: "ShulkerGen847392"
  • generate_custom_password(prefix, length):
    - Customizable prefix and digit count
    - Default: same as above

session_manager.py:
  • save_session(user_id):
    - Writes user_session.json
    - Stores Discord User ID
  • load_session():
    - Reads user_session.json
    - Returns user_id or None
  • clear_session():
    - Deletes user_session.json
    - Called on logout
  • has_saved_session():
    - Checks if session file exists
    - Used for auto-login

EXTERNAL SERVICES:
------------------
tempmail.py:
  • Mail.tm API integration (https://api.mail.tm)
  • generate_temp_mail_account():
    - Creates random username@domain
    - Registers account
    - Gets authentication token
    - Returns: email, password, token
  • wait_for_emails(token, count, timeout):
    - Polls for new emails
    - Returns list of messages
  • get_otp_from_first_email(token):
    - Reads first email
    - Extracts 6-digit OTP with regex
    - Returns OTP string
  • extract_specific_link(text):
    - Parses email for reset link
    - Looks for "Click this link to reset"
    - Returns URL from next line

🔧 CUSTOMIZATION GUIDE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CHANGE PASSWORD FORMAT:
------------------------
Edit utils/password_generator.py:

def generate_shulker_password() -> str:
    # Change prefix and/or length
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(8)])
    return f"MyPrefix{random_numbers}"

CHANGE UI COLORS:
-----------------
Edit gui/styles.py:

COLORS = {
    "accent_purple": "#YOUR_HEX_COLOR",
    "bg_dark": "#YOUR_HEX_COLOR",
    # ... etc
}

CHANGE SERVER ENDPOINT:
-----------------------
Edit config.json:

{
    "flask_server": "http://your-domain.com:port"
}

Or edit utils/api_client.py default:

def __init__(self, base_url: str = "http://your-server:port"):

ADD PROXY SUPPORT:
------------------
Edit automation/acsr.py, line ~26:

proxy_config = {
    'host': 'your.proxy.host',
    'port': 'port',
    'username': 'user',
    'password': 'pass'
}

driver = create_driver(headless=True, use_proxy=True, proxy_config=proxy_config)

DISABLE HEADLESS MODE (for debugging):
---------------------------------------
Edit any automation module call:

driver = create_driver(headless=False)

CHANGE WEBHOOK FORMAT:
----------------------
Edit automation/logger.py, send_webhook():

# Customize the Discord message format
content = "Your custom format with {result['email']}"

🛠️ BUILDING THE EXE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

USING PROVIDED BUILDER:
-----------------------
    python advanced_exe_builder.py

This will:
1. Check Python version (3.8+ required)
2. Install all dependencies
3. Ensure package structure
4. Clean old builds
5. Obfuscate code with PyArmor
6. Create PyInstaller hooks
7. Build single-file EXE
8. Package with README files
9. Output to Release/ folder

MANUAL BUILD (if needed):
-------------------------
1. Install dependencies:
   pip install pyarmor pyinstaller>=6.0

2. Obfuscate code:
   pyarmor gen --output dist_obfuscated --recursive gui
   pyarmor gen --output dist_obfuscated --recursive automation
   pyarmor gen --output dist_obfuscated --recursive utils
   pyarmor gen --output dist_obfuscated run.py main.py tempmail.py

3. Build EXE:
   pyinstaller --onefile --noconsole --name MSPasswordChanger    --add-data "config.json;."    --hidden-import gui --hidden-import automation --hidden-import utils    dist_obfuscated/run.py

4. Copy config.json to dist/

OUTPUT FILES:
-------------
Release/
├── MSPasswordChanger.exe    # Main executable (~50-80MB)
├── README_EXE.txt           # User guide for EXE
└── README_SOURCE.txt        # Developer guide (optional)

🐛 DEBUGGING & TROUBLESHOOTING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMMON ISSUES:
--------------

1. "ModuleNotFoundError: No module named 'X'"
   → pip install -r requirements.txt
   → Make sure all __init__.py files exist

2. "Chrome not found"
   → Install Chrome: https://www.google.com/chrome/
   → Or update chrome_paths in automation/driver.py

3. "seleniumwire certificate error"
   → run.py handles this automatically
   → Or manually: pip uninstall seleniumwire && pip install seleniumwire

4. "Cannot connect to server"
   → Check config.json flask_server URL
   → Ensure Flask server is running
   → Test with: python -c "from utils.api_client import APIClient; print(APIClient().health_check())"

5. "CAPTCHA not displaying"
   → Check PIL installation: pip install Pillow
   → Ensure captcha_*.png files are being created

6. "PyArmor obfuscation failed"
   → Update PyArmor: pip install --upgrade pyarmor
   → Try without obfuscation (comment out obfuscate_code())

7. "PyInstaller EXE doesn't run"
   → Test with --console flag first to see errors
   → Check Windows Defender didn't quarantine
   → Run as Administrator

ENABLE DEBUG LOGGING:
---------------------
Add to top of any module:

import logging
logging.basicConfig(level=logging.DEBUG)

VIEW CHROME BROWSER:
--------------------
Change headless=True to headless=False in:
• automation/core.py
• automation/acsr.py
• automation/reset_password.py

TEST INDIVIDUAL MODULES:
------------------------
# Test password generator
python utils/password_generator.py

# Test tempmail
python tempmail.py

# Test API client
python utils/api_client.py

# Test account scraping (replace with real credentials)
python -c "from automation.core import scrape_account_info; print(scrape_account_info('email@example.com', 'password'))"

📊 UNDERSTANDING THE WORKFLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPLETE PROCESS FOR ONE ACCOUNT:
----------------------------------
1. User adds: user@outlook.com:OldPass123

2. core.scrape_account_info():
   • Opens login.live.com
   • Enters email, clicks Next
   • Handles passkey/password choice
   • Enters password, clicks Sign In
   • Handles "Stay signed in?" prompt
   • Goes to account.microsoft.com/profile
   • Extracts: Name, DOB, Country
   • Goes to secure.skype.com/portal/profile
   • Extracts: Skype ID, Skype Email
   • Goes to xbox.com/en-IN/play/user
   • Extracts: Xbox Gamertag from URL
   • Returns: {email, password, name, dob, region, skype_id, skype_email, gamertag}

3. acsr.submit_acsr_form():
   • Generates tempmail: randomuser@mail.tm
   • Opens account.live.com/acsr
   • Fills Microsoft email
   • Fills tempmail as recovery email
   • Downloads CAPTCHA image
   • Returns: captcha_image, driver, token, tempmail

4. User solves CAPTCHA in GUI

5. acsr_continue.continue_acsr_flow():
   • Submits CAPTCHA solution
   • If wrong: downloads new CAPTCHA, returns "CAPTCHA_RETRY_NEEDED"
   • If correct: continues...
   • Waits for OTP in tempmail inbox
   • Reads first email, extracts 6-digit OTP
   • Submits OTP
   • Fills first/last name
   • Selects DOB dropdowns (month, day, year)
   • Fills country
   • Enters old password
   • Checks Skype checkbox
   • Checks Xbox checkbox
   • Fills Skype ID and email
   • Selects Xbox One radio button
   • Enters Xbox Gamertag
   • Waits for 2nd email (reset link)
   • Extracts password reset URL
   • Returns: reset_link

6. reset_password.perform_password_reset():
   • Opens reset_link
   • Enters email again
   • Fills new password (ShulkerGen123456)
   • Fills confirm password
   • Submits form
   • If rejected: retries with ShulkerCorePass!12
   • Returns: actual_password_used

7. logger.send_webhook():
   • Formats result with all account info
   • Posts to Discord webhook
   • User receives notification with new credentials

⚙️ ADVANCED CONFIGURATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MULTI-THREADING:
----------------
Currently processes accounts sequentially. To parallelize:

In processing_screen.py, modify process_accounts():

from concurrent.futures import ThreadPoolExecutor

def process_accounts(self):
    with ThreadPoolExecutor(max_workers=3) as executor:
        executor.map(self.process_single_account, self.accounts)

Note: CAPTCHA solving is still manual, so limited benefit.

RETRY LOGIC:
------------
Add retry decorator to automation functions:

from functools import wraps
import time

def retry(max_attempts=3, delay=5):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts - 1:
                        raise
                    time.sleep(delay)
            return wrapper
        return decorator

@retry(max_attempts=3, delay=10)
def scrape_account_info(email, password):
    # existing code

DATABASE STORAGE:
-----------------
Instead of immediate webhook, store results in SQLite:

import sqlite3

def store_result(account_info):
    conn = sqlite3.connect('results.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS accounts
                 (email TEXT, old_pass TEXT, new_pass TEXT, ...)''')
    c.execute("INSERT INTO accounts VALUES (?, ?, ?, ...)",
              (account_info['email'], account_info['old_password'], ...))
    conn.commit()
    conn.close()

CAPTCHA AUTO-SOLVE:
-------------------
Integrate 2Captcha or AntiCaptcha API:

# In captcha.py
import requests

def solve_captcha_api(image_base64, api_key):
    # Send to 2captcha
    response = requests.post(
        "https://2captcha.com/in.php",
        data={
            "key": api_key,
            "method": "base64",
            "body": image_base64
        }
    )
    captcha_id = response.json()['request']
    
    # Poll for solution
    # ... implementation
    return solution

🔐 SECURITY BEST PRACTICES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FOR SOURCE CODE DISTRIBUTION:
------------------------------
✓ Always obfuscate before distributing
✓ Don't include your personal config.json
✓ Provide template config with placeholders
✓ Use environment variables for sensitive data
✓ Add license agreement
✓ Watermark/fingerprint each distribution

FOR EXE DISTRIBUTION:
---------------------
✓ Use PyArmor obfuscation (included in builder)
✓ Sign EXE with code signing certificate
✓ Distribute only to authorized users
✓ Implement license key validation
✓ Add HWID binding for single-device use
✓ Use encrypted config

PROTECTING CREDENTIALS:
-----------------------
Never hardcode:
• Discord tokens
• Webhook URLs (or encrypt them)
• API keys
• Server credentials

Use environment variables:
import os
WEBHOOK_URL = os.getenv('WEBHOOK_URL', 'default_url')

📚 DEPENDENCIES EXPLAINED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

discord.py (2.3.0+)
  Purpose: Discord bot integration (for OTP sending)
  Usage: Not directly in client, but needed for server

Flask (3.0.0+)
  Purpose: Web server for authentication API
  Usage: Server-side only, client makes requests

requests (2.31.0+)
  Purpose: HTTP client for API calls, webhook, tempmail
  Usage: api_client.py, logger.py, tempmail.py, captcha.py

customtkinter (5.2.0+)
  Purpose: Modern Tkinter GUI framework
  Usage: All gui/ modules for interface

Pillow (10.0.0+)
  Purpose: Image processing
  Usage: captcha.py (CAPTCHA download), processing_screen.py (display)

selenium (4.15.0+)
  Purpose: Browser automation core
  Usage: All automation/ modules

undetected-chromedriver (3.5.0+)
  Purpose: Anti-detection Chrome driver
  Usage: driver.py for stealth

selenium-wire
  Purpose: Selenium with request/response interception
  Usage: driver.py for proxy support

aiohttp (3.9.0+)
  Purpose: Async HTTP (Discord bot dependency)
  Usage: Not directly used in client

pycountry
  Purpose: Country name validation
  Usage: core.py for region detection

webdriver-manager
  Purpose: Auto-download ChromeDriver
  Usage: driver.py for driver management

📞 SUPPORT & CONTACT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For technical support, customization requests, or licensing:

Developer: Steve
Discord ID: 752512794624867352
Server: http://212.132.120.102:14307

When reporting issues, provide:
• Python version: python --version
• OS: Windows/Linux/Mac + version
• Error message: full traceback
• Steps to reproduce
• Screenshots if GUI issue

💡 TIPS FOR BUYERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SOURCE CODE BUYERS:
-------------------
✓ Read this entire README before starting
✓ Test with 1-2 accounts first
✓ Understand the workflow before customizing
✓ Keep a backup of original source
✓ Document your changes
✓ Test thoroughly after modifications
✓ Contact Steve for help if stuck

CUSTOMIZATION IDEAS:
--------------------
• Add more password formats
• Integrate different temp email services
• Add database for result storage
• Build web interface version
• Add scheduling/automation
• Implement account validation
• Add success rate analytics
• Create account import from various sources

⚖️ LICENSE & LEGAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This software is provided for authorized use only.

SOURCE CODE LICENSE:
• For personal/commercial use by licensee only
• No redistribution or resale of code
• No public posting or sharing
• Modifications allowed for own use
• Attribution required if sharing modified versions
• Tool by Steve - All rights reserved

DISCLAIMER:
• Software provided "as-is" without warranty
• Use at your own risk
• Respect Microsoft Terms of Service
• Ensure legal compliance in your jurisdiction
• Developer not responsible for misuse

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MS Account Password Changer v1.0 | Source Code Edition
Tool by Steve | Protected Code | Authorized Use Only
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
